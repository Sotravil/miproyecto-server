const express = require('express');
const path = require('path');
const fs = require('fs').promises;

const app = express();
const port = 3500;

app.use(express.json());

const usersFile = path.join(__dirname, 'users.json');
const messagesFile = path.join(__dirname, 'messages', 'messages.json');
const adminUsernames = ['admonzin', 'Sotravil', 'MelvinAdm'];
const adminsFile = path.join(__dirname, 'admins.json');

// Load users from file
async function loadUsers() {
  try {
    const data = await fs.readFile(usersFile, 'utf8');
    return JSON.parse(data);
  } catch (err) {
    console.error('Error loading users:', err);
    return [];
  }
}

// Load messages from file                                                                                      LOADMESSAGES PRINCIPLA MENSAJES
async function loadMessages() {
  try {
    const data = await fs.readFile(messagesFile, 'utf8');//                                                                LEE  MENSAJES
    return JSON.parse(data);
  } catch (err) {
    console.error('Error loading messages:', err);
    return [];
  }
}

// Save users to file
async function saveUsers(users) {
  try {
    await fs.writeFile(usersFile, JSON.stringify(users, null, 2));
  } catch (err) {
    console.error('Error saving users:', err);
  }
}

// Save messages to file
async function saveMessages(messages) {  //                                                                             SAVE MESSAGES FUNCTION
  try {
    await fs.writeFile(messagesFile, JSON.stringify(messages, null, 2)); //                                               GUARDA  MENSAJES
  } catch (err) {
    console.error('Error saving messages:', err);
  }
}

// Load admins from file
async function loadAdmins() {
  try {
    const data = await fs.readFile(adminsFile, 'utf8');
    return JSON.parse(data);
  } catch (err) {
    console.error('Error loading admins:', err);
    return {};
  }
}

// Signup endpoint
app.post('/signup', async (req, res) => {
  const { username, password } = req.body;
  if (!username || !password) {
    return res.status(400).json({ message: 'Username and password are required' });
  }

  if (adminUsernames.includes(username)) {
    return res.status(403).json({ message: 'Admin username cannot be used for signup' });
  }

  const users = await loadUsers();
  if (users.some(user => user.username === username)) {
    return res.status(400).json({ message: 'Username already exists' });
  }

  users.push({ username, password });
  await saveUsers(users);

  res.status(200).json({ message: 'Signup successful' });
});

//admin
// Modify the login endpoint to include the greeting message
app.post('/login', async (req, res) => {
    const { username, password } = req.body;
    if (!username || !password) {
        return res.status(400).json({ message: 'Username and password are required' });
    }

    try {
        const users = await loadUsers();
        const admins = await loadAdmins();

        const user = users.find(user => user.username === username);
        if (!user && !Object.keys(admins).includes(username)) {
            return res.status(401).json({ message: 'Invalid credentials' });
        }

        // Create message element for user joining the chat
        const joinChatMessage = { username: '', message: `${username} joined the chat`, colon: false, isGreetingMessage: true };
        const messages = await loadMessages(); // Load current messages
        messages.push(joinChatMessage); // Add join chat message
        await saveMessages(messages); // Save messages with join chat message

        res.status(200).json({ message: 'Login successful' });
    } catch (err) {
        console.error('Error during login:', err);
        res.status(500).json({ message: 'Internal server error' });
    }
});

// Send message endpoint                                                                                  ENVIA  MENSAJES:
app.post('/send-message', async (req, res) => {
  const { username, message } = req.body;
  if (!username || !message) {
      return res.status(400).json({ message: 'Username and message are required' });
  }

  const messages = await loadMessages(); //                                                               LEE  MENSAJES  MESSAGES.JSON
  messages.push({ username, message });
  await saveMessages(messages);  //                                                                                   GUARDA MENSAJES

  // Reverse the messages order
  messages.reverse();//                                                                                                REVERSE  MENSAJES

  res.status(200).end(); // Send an empty response to indicate success
});


// Serve the expired.html file
app.get('/expired.html', (req, res) => {
  res.sendFile(path.join(__dirname, 'expired.html'));
});


// Load messages endpoint
app.get('/load-messages', async (req, res) => {
  const messages = await loadMessages(); //                                                                             CARGA  MENSAJES

  // Filter out deleted messages
  const filteredMessages = messages.filter(msg => !msg.deleted);

  res.json(filteredMessages);
});

// Serve chat.html for root path requests
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'chat.html'));
});

app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
